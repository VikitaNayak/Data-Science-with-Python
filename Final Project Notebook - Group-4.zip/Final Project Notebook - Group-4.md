
# **Data Science Project - Group 4 **
# **Kaggle Survey Data Analysis **
**Submission by - Prachi Sharma | Vikita Nayak**

# 1. Dataset Description
There were 16,716 Kaggle respondents to this survey. The questions covered a broad spectrum, starting with general demographic questions before moving on to specific DS/ML questions for both the working community and the learning one.

-**multipleChoiceResponses.csv ** : Participants' answers to multiple choice questions. Each column contains the answers of one respondent to a specific question.         
-**freeformResponses.csv** : Each time a respondent selected 'Other' and filled the 'Please specify' part, his answer was added in the freeform.            
-**schema.csv** : This file includes all the questions that have been asked, explains each one of them and precise to whom they've been asked (learners, coders...).             
-**RespondentTypeREADME.txt ** : This is to understand how instances are being defined by Kaggle : who are the learners, who are the workers, who are the the coding workers.                   
-**conversionRates.csv** : Currency conversion rates to USD. 

<p>This dataset contains the following data:
<ul>
<li><b>Age</b>
<li><b>EmploymentStatus</b>
<li><b>StudentStatus</b>
<li><b>LearningDataScience</b>
<li><b>CodeWriter</b>
<li><b>CareerSwitcher</b>
<li><b>CurrentJobTitleSelect</b>
<li><b>TitleFit</b>
<li><b>CurrentEmployerType</b>
<li><b>MLToolNextYearSelect</b>
<li><b>MLMethodNextYearSelect</b>
<li><b>LanguageRecommendationSelect</b>
<li><b>PublicDatasetsSelect</b>
<li><b>LearningPlatformSelect</b>
<li><b>LearningDataScienceTime</b>
<li><b>JobSkillImportanceBigData</b>
<li><b>CoursePlatformSelect</b>
<li><b>HardwarePersonalProjectsSelect</b>
<li><b>TimeSpentStudying</b>
<li><b>ProveKnowledgeSelect</b>
<li><b>DataScienceIdentitySelect</b>
<li><b>FormalEducation</b>
<li><b>MajorSelect</b>
<li><b>Tenure</b>
<li><b>PastJobTitlesSelect</b>
<li><b>FirstTrainingSelect</b>
<li><b>LearningCategorySelftTaught</b>

<li><b>MLSkillsSelect</b>
<li><b>MLTechniquesSelect</b>
<li><b>ParentsEducation</b>
<li><b>EmployerIndustry</b>
<li><b>EmployerSize</b>
<li><b>EmployerSizeChange</b>
<li><b>EmployerMLTime</b>
<li><b>EmployerSearchMethod</b>
<li><b>UniversityImportance</b>
<li><b>JobFunctionSelect</b>
<li><b>WorkDataTypeSelect</b>
<li><b>WorkAlgorithmsSelect</b>
<li><b>WorkToolsSelect</b>
<li><b>WorkFrequencySelect</b>
<li><b>WorkMethodsSelect</b>
<li><b>WorkChallengesSelect</b>
<li><b>CompensationAmount</b>
<li><b>CompensationCurrency</b>
<li><b>originCountry</b>
<li><b>exchangeRate</b>
</ul></p>
<p>That is all we need to know about the columns' meaning.</p>

#  Importing all the required packages


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(color_codes=True)
import warnings
warnings.filterwarnings('ignore')
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import plotly.offline as py
py.init_notebook_mode(connected=True)
import plotly.graph_objs as go
import plotly.tools as tls

# print all the outputs in a cell
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"
```


<script>requirejs.config({paths: { 'plotly': ['https://cdn.plot.ly/plotly-latest.min']},});if(!window.Plotly) {{require(['plotly'],function(plotly) {window.Plotly=plotly;});}}</script>


# 2. Reading the dataset 


```python
cvRates = pd.read_csv('conversionRates.csv', encoding="ISO-8859-1", index_col=0)
data = pd.read_csv('multiple Choice Responses.csv', encoding="ISO-8859-1")
schema = pd.read_csv('schema.csv', encoding ="ISO-8859-1")
```


```python
data.shape
data.head(2)
```




    (16716, 228)






<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GenderSelect</th>
      <th>Country</th>
      <th>Age</th>
      <th>EmploymentStatus</th>
      <th>StudentStatus</th>
      <th>LearningDataScience</th>
      <th>CodeWriter</th>
      <th>CareerSwitcher</th>
      <th>CurrentJobTitleSelect</th>
      <th>TitleFit</th>
      <th>...</th>
      <th>JobFactorExperienceLevel</th>
      <th>JobFactorDepartment</th>
      <th>JobFactorTitle</th>
      <th>JobFactorCompanyFunding</th>
      <th>JobFactorImpact</th>
      <th>JobFactorRemote</th>
      <th>JobFactorIndustry</th>
      <th>JobFactorLeaderReputation</th>
      <th>JobFactorDiversity</th>
      <th>JobFactorPublishingOpportunity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Non-binary, genderqueer, or gender non-conforming</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Employed full-time</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>DBA/Database Engineer</td>
      <td>Fine</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Female</td>
      <td>United States</td>
      <td>30.0</td>
      <td>Not employed, but looking for work</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Somewhat important</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 228 columns</p>
</div>




```python
cvRates.shape
cvRates.head(2)
```




    (86, 2)






<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>originCountry</th>
      <th>exchangeRate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>USD</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>EUR</td>
      <td>1.195826</td>
    </tr>
  </tbody>
</table>
</div>



# 3. Data Preparation

### 3.1 Filling null values of two columns with 0 and  Enumerating them


```python
data_PVR=data[["WorkToolsFrequencyPython","WorkToolsFrequencyR"]].fillna(0)
data_PVR.replace(to_replace=['Rarely','Sometimes','Often','Most of the time'], value=[1,2,3,4], inplace=True)
```

### 3.2 Creating new column called PythonVsR which have three typesof values: Python, R and Both


```python
data_PVR['PythonVsR'] = ['R' if (f1 >2 and f1 > f2) else
                        'Python' if (f1<f2 and f2>2) else
                        'Both' if (f1==f2 and f1 >2) else
                        'None' for (f1,f2) in zip(data_PVR["WorkToolsFrequencyR"],data_PVR["WorkToolsFrequencyPython"])]
data['PythonVsR']=data_PVR['PythonVsR']
#Eliminate the Null values
df_PVR = data[data['PythonVsR']!='None']
```


```python
df_PVR['LanguageRecommendationSelect'].fillna('Other',inplace=True)
```

# 4. Findings

## 4.1 Analysis 1 - Language Recommendation to Data Scientists beginners?


*'What do you use for data science stuff, R or Python ?'* 
In this section of the analysis we try to weigh Python and R to find out which is the ideal language for data science. This analysis will be helpful in recommending aspiring data scientists which language to start with.

We begin with identifing the participants whose recommendation can be considered viable. For this we believe people who are currently working(not students) can give valuable feedback that is inline with the work of Data Science.

We'll be only looking at the 
***Working people (coding workers)- Respondents who indicated that they were "Employed full-time" or "Employed part-time" AND that they write code to analyze data in their current job.***     


For classifying Python, R or Both users, we have used a question about frequency use of Python and R by participants-

    Python Users - Use Python Most of the time/often & don't use R
    R Users - Use R Most of the time/often & don't use Python
    Both Users - Use both R and Python equally & at least often


```python
print("Participants using Python: ",len(df_PVR[df_PVR['PythonVsR']=='Python']))
print("Participants using R: ",len(df_PVR[df_PVR['PythonVsR']=='R']))
print("Participants using both Python and R: ",len(df_PVR[df_PVR['PythonVsR']=='Both']))
```

    Participants using Python:  3438
    Participants using R:  1851
    Participants using both Python and R:  878
    


```python
Python_users = len(df_PVR[df_PVR['PythonVsR']=='Python'])
R_users = len(df_PVR[df_PVR['PythonVsR']=='R'])
Both_users = len(df_PVR[df_PVR['PythonVsR']=='Both'])
```


```python
d={'Users':['Python','R','Both'],'Numbers':[Python_users,R_users,Both_users]}
users_df = pd.DataFrame(data=d)
```


```python
sns.factorplot(y='Numbers',x= 'Users',data=users_df, kind='bar',aspect=2, legend=True)
```




    <seaborn.axisgrid.FacetGrid at 0x1c22beaacc0>




![png](output_23_1.png)


***Frequency of Python as a tool is almost twice as compared to R***

### ML methods / algorithms and skills for R and Python


```python
df_PVR['WorkMethodsSelect']=df_PVR['WorkMethodsSelect'].fillna('None')
techniques = ['Bayesian Techniques','Data Visualization', 'Logistic Regression','Natural Language Processing',
 'kNN and Other Clustering','Neural Networks','PCA and Dimensionality Reduction',
 'Time Series Analysis', 'Text Analytics','Cross-Validation']

df_PVR['WorkAlgorithmsSelect']=df_PVR['WorkAlgorithmsSelect'].fillna('None')
algorithms = ['Bayesian Techniques','Decision Trees','Random Forests','Regression/Logistic Regression',
 'CNNs', 'RNNs', 'Gradient Boosted Machines','SVMs','GANs','Ensemble Methods']

```


```python
d_t={}
for t in techniques :
    d_t[t]={'Python':0,'R':0,'Both':0}
    for (i,elem) in zip(range(df_PVR.shape[0]),df_PVR['WorkMethodsSelect']):
        if t in elem : 
            d_t[t][df_PVR['PythonVsR'].iloc[i]]+=1
    d_t[t]['Python']=100*d_t[t]['Python']/len(df_PVR[df_PVR['PythonVsR']=='Python'])
    d_t[t]['R']=100*d_t[t]['R']/len(df_PVR[df_PVR['PythonVsR']=='R'])
    d_t[t]['Both']=100*d_t[t]['Both']/len(df_PVR[df_PVR['PythonVsR']=='Both'])
    
d_a={}
for a in algorithms :
    d_a[a]={'Python':0,'R':0,'Both':0}
    for (i,elem) in zip(range(df_PVR.shape[0]),df_PVR['WorkAlgorithmsSelect']):
        if a in elem : 
            d_a[a][df_PVR['PythonVsR'].iloc[i]]+=1
    d_a[a]['Python']=100*d_a[a]['Python']/len(df_PVR[df_PVR['PythonVsR']=='Python'])
    d_a[a]['R']=100*d_a[a]['R']/len(df_PVR[df_PVR['PythonVsR']=='R'])
    d_a[a]['Both']=100*d_a[a]['Both']/len(df_PVR[df_PVR['PythonVsR']=='Both'])
            
f,ax=plt.subplots(1,2,figsize=(20,10))

(pd.DataFrame(d_t)).transpose().plot(kind='bar',ax=ax[0],color = ['#1D5939','#660000','#BB3242'],alpha = .8)
ax[0].set_title("Technique usage by R & Python users")
ax[0].set_ylabel('')
ax[0].set_xlabel("Method")

(pd.DataFrame(d_a)).transpose().plot(kind='bar',ax=ax[1],color = ['#1D5939','#660000','#BB3242'],alpha = .8)
ax[1].set_title("Algorithm usage by R & Python users")
ax[1].set_ylabel('')
ax[1].set_xlabel("Algorithm")

plt.tight_layout()
plt.show();
```


![png](output_27_0.png)


### Overall Language Recommendation count by Language Users


```python
plt.figure(figsize=(12,8))
sns.countplot(y='LanguageRecommendationSelect',hue='PythonVsR',data=df_PVR)
plt.xlabel("Language Users", fontsize=13)
plt.ylabel("Number of recommenders", fontsize=13)
plt.title("Recommended language", fontsize=13)
plt.show();

```


![png](output_29_0.png)


As shown in the graph above, we noticed that the most recommended languages are Python and R.We will further dive in to find more insights

### Language Recommendation % 


```python
mask_R=(df_PVR['LanguageRecommendationSelect'] == 'R')& (df_PVR['PythonVsR']=='Python')
print('Proportion of Python users who recommend R as the first language to learn: {:0.2f}%'\
      .format(100*len(df_PVR[mask_R])/len(df_PVR[df_PVR['PythonVsR']=='Python'])))
m_R= 100*len(df_PVR[mask_R])/len(df_PVR[df_PVR['PythonVsR']=='Python'])

mask_P=(df_PVR['LanguageRecommendationSelect'] == 'Python')& (df_PVR['PythonVsR']=='R')
print('Proportion of R users who recommend Python as the first language to learn: {:0.2f}%'\
      .format(100*len(df_PVR[mask_P])/len(df_PVR[df_PVR['PythonVsR']=='R'])))
m_p=100*len(df_PVR[mask_P])/len(df_PVR[df_PVR['PythonVsR']=='R'])

```

    Proportion of Python users who recommend R as the first language to learn: 2.68%
    Proportion of R users who recommend Python as the first language to learn: 23.12%
    

Now,Lets plot the graph of Language Recommendation to new DS by Python and R Users


```python
d={'Language':['Python users who recommend R','R users who recommend Python'],'Recommendation(%)':[m_R,m_p]}
df_graph_pr = pd.DataFrame(data=d)
```


```python
df_graph_pr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Language</th>
      <th>Recommendation(%)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Python users who recommend R</td>
      <td>2.675974</td>
    </tr>
    <tr>
      <th>1</th>
      <td>R users who recommend Python</td>
      <td>23.122636</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.factorplot(y='Recommendation(%)',x= 'Language',data=df_graph_pr, kind='bar',aspect=2)
```




    <seaborn.axisgrid.FacetGrid at 0x1c226460588>




![png](output_36_1.png)


### Observation: We found that R users recommends Python language to new DS rather than R

# 4.2 Analysis 2 - Where are Data Scientists valued the most?

#### We want to know that which country value the Data Scientist the most in terms of Salary


```python
df_ds=data[['GenderSelect','Country','EmploymentStatus','CurrentJobTitleSelect','CompensationAmount','CompensationCurrency']]
```

#### We are only keeping fulltime, part time and freelancer respondents as we are focusing on salary distribution


```python
 df_ds=df_ds[(df_ds.EmploymentStatus== 'Employed full-time') | \
        (df_ds.EmploymentStatus == 'Independent contractor, freelancer, or self-employed') | \
        (df_ds.EmploymentStatus == 'Employed part-time')]

```

#### Considering only Data scientists


```python
df_ds=df_ds[df_ds.CurrentJobTitleSelect == 'Data Scientist']
```


```python
df_ds.drop('CurrentJobTitleSelect',axis=1, inplace=True)
```

#### Cleaning CompensationAmount Column


```python
df_ds['CompensationAmount'] = df_ds['CompensationAmount'].fillna(0)
df_ds['CompensationAmount'] = df_ds.CompensationAmount.apply(lambda x: 0 if (pd.isnull(x) or (x=='-') or (x==0))
                                                       else float(x.replace(',','')))
```


Problem with taking Salary from different country is that the figures are exclusive of the GDP rate of a country.
Consider 1 USD i.e. equivalent to 64.92 Indian Rupee. You can do with 1USD in India more than what you would do with 1USD in the US.

As every country has different cost of living, we are using Purchasing Power Parity(PPP) concept to convert currencies without using market exchange rates. The purchasing power of a currency refers to the quantity of the currency needed to purchase a given unit of a good, or common basket of goods and services.

***In our analysis we have included PPP while calculating the salary.***

**We have taken the purchasing power parity rate from here **:http://www.imf.org/external/datamapper/PPPEX@WEO/OEMDC/ADVEC/WEOWORLD/IND


```python
ppp={'Countries':['United States','India','United Kingdom','Germany','France','Brazil','Canada','Spain','Australia','Russia','Italy',"People 's Republic of China",'Netherlands'],
           'Currency':['USD','INR','GBP','EUR','EUR','BRL','CAD','EUR','AUD','RUB','EUR','CNY','EUR'],
           'PPP':[1.00,17.7,0.7,0.78,0.81,2.05,1.21,0.66,1.46,25.13,0.74,3.51,0.8]}

ppp = pd.DataFrame(data=ppp)
```

Now, we have ppp table and we will merge it with our conversion rates columns to map the ppp rates with corresponding country


```python
rates=ppp.merge(cvRates,left_on='Currency',right_on='originCountry',how='left')
rates['PPP/ER']=rates['PPP']*rates['exchangeRate']
```


```python
rates=rates[['Countries','PPP','PPP/ER']]
rates
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Countries</th>
      <th>PPP</th>
      <th>PPP/ER</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>United States</td>
      <td>1.00</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>India</td>
      <td>17.70</td>
      <td>0.276474</td>
    </tr>
    <tr>
      <th>2</th>
      <td>United Kingdom</td>
      <td>0.70</td>
      <td>0.926932</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Germany</td>
      <td>0.78</td>
      <td>0.932744</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>0.81</td>
      <td>0.968619</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Brazil</td>
      <td>2.05</td>
      <td>0.658767</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Canada</td>
      <td>1.21</td>
      <td>0.996662</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Spain</td>
      <td>0.66</td>
      <td>0.789245</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Australia</td>
      <td>1.46</td>
      <td>1.171373</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Russia</td>
      <td>25.13</td>
      <td>0.437312</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Italy</td>
      <td>0.74</td>
      <td>0.884911</td>
    </tr>
    <tr>
      <th>11</th>
      <td>People 's Republic of China</td>
      <td>3.51</td>
      <td>0.537030</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Netherlands</td>
      <td>0.80</td>
      <td>0.956661</td>
    </tr>
  </tbody>
</table>
</div>



Here, we are mapping the conversion rates with our original data frame


```python
df_new=df_ds.merge(cvRates,left_on='CompensationCurrency',right_on='originCountry',how='left')
```

Now, the conversion rates is mapped with the rates df where we have the ppp rates per country


```python
df1=df_new.merge(rates,left_on='Country',right_on='Countries',how='left')
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GenderSelect</th>
      <th>Country</th>
      <th>EmploymentStatus</th>
      <th>CompensationAmount</th>
      <th>CompensationCurrency</th>
      <th>originCountry</th>
      <th>exchangeRate</th>
      <th>Countries</th>
      <th>PPP</th>
      <th>PPP/ER</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Male</td>
      <td>Brazil</td>
      <td>Employed full-time</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Brazil</td>
      <td>2.05</td>
      <td>0.658767</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Male</td>
      <td>India</td>
      <td>Employed full-time</td>
      <td>95000.0</td>
      <td>INR</td>
      <td>INR</td>
      <td>0.015620</td>
      <td>India</td>
      <td>17.70</td>
      <td>0.276474</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Male</td>
      <td>Colombia</td>
      <td>Employed full-time</td>
      <td>156000000.0</td>
      <td>COP</td>
      <td>COP</td>
      <td>0.000342</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Male</td>
      <td>Germany</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>150000.0</td>
      <td>EUR</td>
      <td>EUR</td>
      <td>1.195826</td>
      <td>Germany</td>
      <td>0.78</td>
      <td>0.932744</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Male</td>
      <td>United Kingdom</td>
      <td>Employed full-time</td>
      <td>130000.0</td>
      <td>GBP</td>
      <td>GBP</td>
      <td>1.324188</td>
      <td>United Kingdom</td>
      <td>0.70</td>
      <td>0.926932</td>
    </tr>
  </tbody>
</table>
</div>



We have all the required columns now after merging different tables and below is the salary calculation considering exchange rate and purchaisng power parity concept


```python
df1['AdjustedSalary']=df1['CompensationAmount']*df1['exchangeRate']/df1['PPP/ER']
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GenderSelect</th>
      <th>Country</th>
      <th>EmploymentStatus</th>
      <th>CompensationAmount</th>
      <th>CompensationCurrency</th>
      <th>originCountry</th>
      <th>exchangeRate</th>
      <th>Countries</th>
      <th>PPP</th>
      <th>PPP/ER</th>
      <th>AdjustedSalary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Male</td>
      <td>Brazil</td>
      <td>Employed full-time</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Brazil</td>
      <td>2.05</td>
      <td>0.658767</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Male</td>
      <td>India</td>
      <td>Employed full-time</td>
      <td>95000.0</td>
      <td>INR</td>
      <td>INR</td>
      <td>0.015620</td>
      <td>India</td>
      <td>17.70</td>
      <td>0.276474</td>
      <td>5367.231638</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Male</td>
      <td>Colombia</td>
      <td>Employed full-time</td>
      <td>156000000.0</td>
      <td>COP</td>
      <td>COP</td>
      <td>0.000342</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Male</td>
      <td>Germany</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>150000.0</td>
      <td>EUR</td>
      <td>EUR</td>
      <td>1.195826</td>
      <td>Germany</td>
      <td>0.78</td>
      <td>0.932744</td>
      <td>192307.692308</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Male</td>
      <td>United Kingdom</td>
      <td>Employed full-time</td>
      <td>130000.0</td>
      <td>GBP</td>
      <td>GBP</td>
      <td>1.324188</td>
      <td>United Kingdom</td>
      <td>0.70</td>
      <td>0.926932</td>
      <td>185714.285714</td>
    </tr>
  </tbody>
</table>
</div>




```python
salary = {}
for country in df1['Country'].value_counts().index :
    salary[country]=df1[df1['Country']==country]['AdjustedSalary'].median()
    
median_wages = pd.DataFrame.from_dict(data=salary, orient='index').round(2)
median_wages.sort_values(by=list(median_wages),axis=0, ascending=True, inplace=True)

```


```python
median_wages.dropna(inplace=True)
```


```python
median_wages
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Russia</th>
      <td>24830.88</td>
    </tr>
    <tr>
      <th>India</th>
      <td>56497.18</td>
    </tr>
    <tr>
      <th>France</th>
      <td>58024.69</td>
    </tr>
    <tr>
      <th>Brazil</th>
      <td>58536.59</td>
    </tr>
    <tr>
      <th>Spain</th>
      <td>60606.06</td>
    </tr>
    <tr>
      <th>Italy</th>
      <td>66216.22</td>
    </tr>
    <tr>
      <th>People 's Republic of China</th>
      <td>68376.07</td>
    </tr>
    <tr>
      <th>United Kingdom</th>
      <td>71428.57</td>
    </tr>
    <tr>
      <th>Netherlands</th>
      <td>76250.00</td>
    </tr>
    <tr>
      <th>Germany</th>
      <td>76923.08</td>
    </tr>
    <tr>
      <th>Canada</th>
      <td>77479.34</td>
    </tr>
    <tr>
      <th>Australia</th>
      <td>95547.95</td>
    </tr>
    <tr>
      <th>United States</th>
      <td>120000.00</td>
    </tr>
  </tbody>
</table>
</div>



**Inflation rate has been taken from https://tradingeconomics.com/country-list/inflation-rate**


```python
inflations={'Countries':['United States','India','United Kingdom','Germany','France','Brazil','Canada','Spain','Australia','Russia','Italy',"People 's Republic of China",'Netherlands'],
           'infrate_2013':[106.83,131.98,110.15,105.68,105.01,119.37,105.45,107.21,107.70,121.64,107.20,111.16,107.48],
           'infrate_2017':[113.10,162.01,116.51,109.6,107.1,156.73,112.39,109.13,113.48,168.50,108.61,119.75,111.55],
           'medrate':[15480,615,12399,14098,12445,2247,15181,7284,15026,4129,6874,1786,14450]}

inflations_rates = pd.DataFrame(inflations)
inflations_rates['adjusted_medians']=(inflations_rates['medrate']*inflations_rates['infrate_2017']/inflations_rates['infrate_2013']).round(2)
inflations_rates
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Countries</th>
      <th>infrate_2013</th>
      <th>infrate_2017</th>
      <th>medrate</th>
      <th>adjusted_medians</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>United States</td>
      <td>106.83</td>
      <td>113.10</td>
      <td>15480</td>
      <td>16388.54</td>
    </tr>
    <tr>
      <th>1</th>
      <td>India</td>
      <td>131.98</td>
      <td>162.01</td>
      <td>615</td>
      <td>754.93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>United Kingdom</td>
      <td>110.15</td>
      <td>116.51</td>
      <td>12399</td>
      <td>13114.91</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Germany</td>
      <td>105.68</td>
      <td>109.60</td>
      <td>14098</td>
      <td>14620.94</td>
    </tr>
    <tr>
      <th>4</th>
      <td>France</td>
      <td>105.01</td>
      <td>107.10</td>
      <td>12445</td>
      <td>12692.69</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Brazil</td>
      <td>119.37</td>
      <td>156.73</td>
      <td>2247</td>
      <td>2950.26</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Canada</td>
      <td>105.45</td>
      <td>112.39</td>
      <td>15181</td>
      <td>16180.11</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Spain</td>
      <td>107.21</td>
      <td>109.13</td>
      <td>7284</td>
      <td>7414.45</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Australia</td>
      <td>107.70</td>
      <td>113.48</td>
      <td>15026</td>
      <td>15832.41</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Russia</td>
      <td>121.64</td>
      <td>168.50</td>
      <td>4129</td>
      <td>5719.64</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Italy</td>
      <td>107.20</td>
      <td>108.61</td>
      <td>6874</td>
      <td>6964.41</td>
    </tr>
    <tr>
      <th>11</th>
      <td>People 's Republic of China</td>
      <td>111.16</td>
      <td>119.75</td>
      <td>1786</td>
      <td>1924.01</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Netherlands</td>
      <td>107.48</td>
      <td>111.55</td>
      <td>14450</td>
      <td>14997.19</td>
    </tr>
  </tbody>
</table>
</div>




```python
tmp=median_wages.reset_index()
tmp = tmp.rename(columns={'index': 'Country', 0: 'median_income'})

inflations_rates=inflations_rates.merge(tmp,left_on='Countries',right_on='Country',how='left')
inflations_rates['ratio_incomes']=(inflations_rates['median_income']/inflations_rates['adjusted_medians']).round(2)

tmp2=inflations_rates[['Country','ratio_incomes']]
tmp2.sort_values(by='ratio_incomes',axis=0, ascending=True, inplace=True)
```

##  Salary Distribution Before GDP Calculation


```python

data = [ dict(
        type = 'choropleth',
       locations =tmp['Country'],
        locationmode = 'country names',
        z = tmp['median_income'],
        text = tmp['Country'],
        colorscale = [[0,"rgb(5, 10, 172)"],[0.35,"rgb(40, 60, 190)"],[0.5,"rgb(70, 100, 245)"],
            [0.6,"rgb(90, 120, 245)"],[0.7,"rgb(106, 137, 247)"],[1,"rgb(220, 220, 220)"]],
        autocolorscale = False,
        reversescale = True,
        marker = dict(
            line = dict (
                color = 'rgb(180,180,180)',
                width = 0.5
            ) ),
        colorbar = dict(
            autotick = False,
            title = 'Salary in USD'),
      ) ]

layout = dict(
    title = 'Salary Distribution by countries (USD)',
    geo = dict(
        showframe = False,
        showcoastlines = True,
        projection = dict(
            type = 'Mercator'
        )
    )
)

fig = dict( data=data, layout=layout )
py.iplot( fig, validate=False, filename='world-map')
```


<div id="139bff5f-1c4e-4235-bc91-0a8a77fc68af" style="height: 525px; width: 100%;" class="plotly-graph-div"></div><script type="text/javascript">require(["plotly"], function(Plotly) { window.PLOTLYENV=window.PLOTLYENV || {};window.PLOTLYENV.BASE_URL="https://plot.ly";Plotly.newPlot("139bff5f-1c4e-4235-bc91-0a8a77fc68af", [{"type": "choropleth", "locations": ["Russia", "India", "France", "Brazil", "Spain", "Italy", "People 's Republic of China", "United Kingdom", "Netherlands", "Germany", "Canada", "Australia", "United States"], "locationmode": "country names", "z": [24830.88, 56497.18, 58024.69, 58536.59, 60606.06, 66216.22, 68376.07, 71428.57, 76250.0, 76923.08, 77479.34, 95547.95, 120000.0], "text": ["Russia", "India", "France", "Brazil", "Spain", "Italy", "People 's Republic of China", "United Kingdom", "Netherlands", "Germany", "Canada", "Australia", "United States"], "colorscale": [[0, "rgb(5, 10, 172)"], [0.35, "rgb(40, 60, 190)"], [0.5, "rgb(70, 100, 245)"], [0.6, "rgb(90, 120, 245)"], [0.7, "rgb(106, 137, 247)"], [1, "rgb(220, 220, 220)"]], "autocolorscale": false, "reversescale": true, "marker": {"line": {"color": "rgb(180,180,180)", "width": 0.5}}, "colorbar": {"autotick": false, "title": "Salary in USD"}}], {"title": "Salary Distribution by countries (USD)", "geo": {"showframe": false, "showcoastlines": true, "projection": {"type": "Mercator"}}}, {"showLink": true, "linkText": "Export to plot.ly"})});</script>


## Salary Distribution After GDP Calculation


```python
median_wages.dropna(inplace=True)
data = [ dict(
        type = 'choropleth',
       locations = tmp2['Country'],
        locationmode = 'country names',
        z = tmp2['ratio_incomes'],
        text = tmp2['Country'],
        colorscale = [[0,"rgb(5, 10, 172)"],[0.35,"rgb(40, 60, 190)"],[0.5,"rgb(70, 100, 245)"],
            [0.6,"rgb(90, 120, 245)"],[0.7,"rgb(106, 137, 247)"],[1,"rgb(220, 220, 220)"]],
        autocolorscale = False,
        reversescale = True,
        marker = dict(
            line = dict (
                color = 'rgb(180,180,180)',
                width = 0.5
            ) ),
        colorbar = dict(
            autotick = False,
            title = 'Salary'),
      ) ]

layout = dict(
    title = 'Most Valued Data Scientist Countries',
    geo = dict(
        showframe = False,
        showcoastlines = True,
        projection = dict(
            type = 'Mercator'
        )
    )
)

fig = dict( data=data, layout=layout )
py.iplot( fig, validate=False, filename='world-map')
```


<div id="eed135ad-aa67-47a7-b53a-a7da0a8c990b" style="height: 525px; width: 100%;" class="plotly-graph-div"></div><script type="text/javascript">require(["plotly"], function(Plotly) { window.PLOTLYENV=window.PLOTLYENV || {};window.PLOTLYENV.BASE_URL="https://plot.ly";Plotly.newPlot("eed135ad-aa67-47a7-b53a-a7da0a8c990b", [{"type": "choropleth", "locations": ["Russia", "France", "Canada", "Netherlands", "Germany", "United Kingdom", "Australia", "United States", "Spain", "Italy", "Brazil", "People 's Republic of China", "India"], "locationmode": "country names", "z": [4.34, 4.57, 4.79, 5.08, 5.26, 5.45, 6.03, 7.32, 8.17, 9.51, 19.84, 35.54, 74.84], "text": ["Russia", "France", "Canada", "Netherlands", "Germany", "United Kingdom", "Australia", "United States", "Spain", "Italy", "Brazil", "People 's Republic of China", "India"], "colorscale": [[0, "rgb(5, 10, 172)"], [0.35, "rgb(40, 60, 190)"], [0.5, "rgb(70, 100, 245)"], [0.6, "rgb(90, 120, 245)"], [0.7, "rgb(106, 137, 247)"], [1, "rgb(220, 220, 220)"]], "autocolorscale": false, "reversescale": true, "marker": {"line": {"color": "rgb(180,180,180)", "width": 0.5}}, "colorbar": {"autotick": false, "title": "Salary"}}], {"title": "Most Valued Data Scientist Countries", "geo": {"showframe": false, "showcoastlines": true, "projection": {"type": "Mercator"}}}, {"showLink": true, "linkText": "Export to plot.ly"})});</script>


#### Observation: We observed that salary distribution is totally different when we consider the GDP/PPP concept and this completely change the way when we analyze the countries where the data scientists are valued the most. 

#### In the first graph, we found that United States is valuing the Data Scientists the most followed by United Kingdom whereas in the second graph when we consider PPP concept, India is the one who is valuing the Data Scientists the most followed by China


# 4.3 Analysis 3 - What you should have to get paid the most 

We are analyzing what one should have to get paid the most and we are predicting this for Data Scientist and Data Analyst only using Random Forest Classifier


```python
data = pd.read_csv('multiple Choice Responses.csv', encoding="ISO-8859-1")
```


```python
df_skills = data[['EmploymentStatus','CodeWriter','CurrentJobTitleSelect','PublicDatasetsSelect',
'LearningPlatformUsefulnessCollege',
'LearningPlatformUsefulnessCompany',
'LearningPlatformUsefulnessNewsletters',
'LearningPlatformUsefulnessCommunities',
'LearningPlatformUsefulnessDocumentation',
'LearningPlatformUsefulnessCourses',
'LearningPlatformUsefulnessProjects',
'LearningPlatformUsefulnessSO',
'LearningPlatformUsefulnessTextbook',
'LearningPlatformUsefulnessTradeBook',
'LearningPlatformUsefulnessTutoring',
'LearningPlatformUsefulnessYouTube',
'JobSkillImportanceBigData',
'JobSkillImportanceDegree',
'JobSkillImportanceStats',
'JobSkillImportanceEnterpriseTools',
'JobSkillImportancePython',
'JobSkillImportanceR',
'JobSkillImportanceSQL',
'JobSkillImportanceKaggleRanking',
'JobSkillImportanceMOOC',
'JobSkillImportanceVisualizations',
'FormalEducation',
'MajorSelect',
'Tenure',
'LearningCategorySelftTaught',
'LearningCategoryOnlineCourses',
'LearningCategoryWork',
'LearningCategoryUniversity',
'LearningCategoryKaggle',
'LearningCategoryOther',
'MLTechniquesSelect','CompensationAmount','CompensationCurrency',
'WorkToolsFrequencyAmazonML',
'WorkToolsFrequencyAngoss',
'WorkToolsFrequencyC',
'WorkToolsFrequencyCloudera',
'WorkToolsFrequencyDataRobot',
'WorkToolsFrequencyFlume',
'WorkToolsFrequencyGCP',
'WorkToolsFrequencyHadoop',
'WorkToolsFrequencyIBMCognos',
'WorkToolsFrequencyIBMSPSSModeler',
'WorkToolsFrequencyIBMSPSSStatistics',
'WorkToolsFrequencyIBMWatson',
'WorkToolsFrequencyImpala',
'WorkToolsFrequencyJava',
'WorkToolsFrequencyJulia',
'WorkToolsFrequencyKNIMECommercial',
'WorkToolsFrequencyKNIMEFree',
'WorkToolsFrequencyMathematica',
'WorkToolsFrequencyMATLAB',
'WorkToolsFrequencyAzure',
'WorkToolsFrequencyExcel',
'WorkToolsFrequencyMicrosoftRServer',
'WorkToolsFrequencyMinitab',
'WorkToolsFrequencyNoSQL',
'WorkToolsFrequencyOracle',
'WorkToolsFrequencyOrange',
'WorkToolsFrequencyPerl',
'WorkToolsFrequencyQlik',
'WorkToolsFrequencyRapidMinerCommercial',
'WorkToolsFrequencyRapidMinerFree',
'WorkToolsFrequencySalfrod',
'WorkToolsFrequencySAPBusinessObjects',
'WorkToolsFrequencySASBase',
'WorkToolsFrequencySASEnterprise',
'WorkToolsFrequencySASJMP',
'WorkToolsFrequencySpark',
'WorkToolsFrequencyStan',
'WorkToolsFrequencyStatistica',
'WorkToolsFrequencyTensorFlow',
'WorkToolsFrequencyTIBCO',
'WorkToolsFrequencyUnix'\
]]
```


```python
df_skills['CompensationAmount'] = df_skills.CompensationAmount.apply(lambda x: 0 if (pd.isnull(x) or (x=='-') or (x==0))
                                                       else float(x.replace(',','')))
```


```python
df_skills=df_skills[df_skills.CompensationAmount.notnull()]
```


```python
df_skills=df_skills[df_skills.CompensationCurrency.notnull()]
```


```python
df=df_skills.merge(cvRates,left_on='CompensationCurrency',right_on='originCountry',how='left')
```


```python
df['CompensationAmountUSD'] = df.CompensationAmount*df.exchangeRate
```


```python
df = df[df["CompensationAmountUSD"].notnull()]
```


```python
df.drop(['originCountry','CompensationAmount','CompensationCurrency','exchangeRate'], axis=1, inplace=True)
```


```python
df1=df[df.CurrentJobTitleSelect == 'Data Scientist']
```


```python
y = df1["CompensationAmountUSD"]
X = df1.drop("CompensationAmountUSD", 1)
```


```python
X = X.fillna(0)
X_dummied = pd.get_dummies(X)
y_binary = y > 50000
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_dummied, y_binary, random_state=0)
clf = RandomForestClassifier(n_estimators=20, random_state=0).fit(X_train, y_train)

print("score:{}".format(clf.score(X_test, y_test)))
```

    score:0.6257668711656442
    


```python
outds = pd.DataFrame()
outds["data_scientist_feature_name"] = X_dummied.columns.tolist()
outds["feature_importance"] = clf.feature_importances_
outds.sort_values("feature_importance",ascending=False).to_csv("results.csv", index=False)
```


```python
top_10=outds.sort_values("feature_importance",ascending=False).head(10)
```


```python
sns.factorplot(x='feature_importance', y='data_scientist_feature_name', data=top_10, kind='bar', aspect=3)
```




    <seaborn.axisgrid.FacetGrid at 0x1c224823b38>




![png](output_88_1.png)



```python
df2=df[df.CurrentJobTitleSelect == 'Data Analyst']
```


```python
#df = df.drop('CompensationAmount', 1)
y1 = df2["CompensationAmountUSD"]
X1 = df2.drop("CompensationAmountUSD", 1)

```


```python
X1 = X1.fillna(0)
X_dummied1 = pd.get_dummies(X1)
y_binary1 = y1 > 50000
```


```python
X_train1, X_test1, y_train1, y_test1 = train_test_split(X_dummied1, y_binary1, random_state=0)
clf = RandomForestClassifier(n_estimators=20, random_state=0).fit(X_train1, y_train1)

print("score:{}".format(clf.score(X_test1, y_test1)))
```

    score:0.64
    


```python
outda = pd.DataFrame()
outda["data_analyst_feature_name"] = X_dummied1.columns.tolist()
outda["feature_importance"] = clf.feature_importances_
outda.sort_values("feature_importance",ascending=False).to_csv("results.csv", index=False)
```


```python
top_10=outda.sort_values("feature_importance",ascending=False).head(10)
```


```python
sns.factorplot(x='feature_importance', y='data_analyst_feature_name', data=top_10, kind='bar', aspect=3)
```




    <seaborn.axisgrid.FacetGrid at 0x1c224823198>




![png](output_95_1.png)



```python
top10_da = outda.sort_values("feature_importance",ascending=False).head(10)
top10_ds = outds.sort_values("feature_importance",ascending=False).head(10)
```


```python
top10_dao=top10_da.data_analyst_feature_name
top10_da_fea=top10_dao.values[:10]
```


```python
top10_dso=top10_ds.data_scientist_feature_name
top10_ds_fea=top10_dso.values[:10]
```


```python
from matplotlib_venn import venn2
A =set(top10_da_fea)
B =set(top10_ds_fea)
# First way to call the 2 group Venn diagram:
v=venn2([A,B],('Data Scientist', 'Data Analyst'))


v.get_label_by_id('10').set_text('')
v.get_label_by_id('11').set_text('\n'.join(A&B))
v.get_label_by_id('01').set_text('')
#v.get_label_by_id('001').set_text('\n'.join(C-A-B))
v.get_label_by_id('01').set_text('')
plt.annotate(',\n'.join(B-A), xy=v.get_label_by_id('01').get_position() +
             np.array([0, 0.8]), xytext=(-20,40), ha='center',
             textcoords='offset points',
             bbox=dict(boxstyle='round,pad=20', fc='black', alpha=1),
             arrowprops=dict(arrowstyle='->',              
                             connectionstyle='arc',color='gray'))


plt.show()



```




    Text(-20,40,'EmploymentStatus_Employed part-time,\nTenure_6 to 10 years,\nFormalEducation_Doctoral degree')




![png](output_99_1.png)

